package ru.innopolis.stc9.servlets.db.dao;

import ru.innopolis.stc9.servlets.pojo.Student;
import ru.innopolis.stc9.servlets.pojo.Team;
import ru.innopolis.stc9.servlets.pojo.User;

import java.util.ArrayList;

public interface StudentDAO {
//    boolean add(Student student);
//
//    boolean update(Student oldStudent, Student newStudent);
//
//    boolean delete(Student student);
//
//    Student get(User user);
//
//    ArrayList<Student> get(Team team);
}
