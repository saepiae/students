package ru.innopolis.stc9.servlets.db.dao;

import ru.innopolis.stc9.servlets.pojo.Teacher;
import ru.innopolis.stc9.servlets.pojo.User;

public interface TeacherDAO {
//    boolean add(Teacher teacher);
//    boolean update(Teacher oldTeacher, Teacher newTeacher);
//    boolean delete(Teacher teacher);
//    Teacher get(User user);
}
