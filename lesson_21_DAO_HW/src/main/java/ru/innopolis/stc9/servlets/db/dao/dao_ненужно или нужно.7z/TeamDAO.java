package ru.innopolis.stc9.servlets.db.dao;

import ru.innopolis.stc9.servlets.pojo.Program;
import ru.innopolis.stc9.servlets.pojo.Team;

import java.util.ArrayList;

public interface TeamDAO {
    boolean add(Team team);
    boolean update(Team oldTeam, Team newTeam);
    boolean delete(Team team);
    Team get(int id);
    ArrayList<Team> get(Program program);
}
