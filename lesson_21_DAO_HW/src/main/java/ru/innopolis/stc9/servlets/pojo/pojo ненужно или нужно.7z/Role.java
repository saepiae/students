package ru.innopolis.stc9.servlets.pojo;

public enum Role {
    NO_SUCH_USER, STUDENT, TEACHER, ADMIN;
}
